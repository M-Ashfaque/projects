document.addEventListener('DOMContentLoaded', () => {
    // Theme Toggle
    const themeToggleBtn = document.querySelector('.theme-toggle-btn');
    const body = document.body;

    // Check for saved theme preference or use system preference
    const savedTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

    if (savedTheme) {
        body.classList.add(savedTheme);
    } else if (systemPrefersDark) {
        body.classList.add('dark-theme');
    }

    // Theme toggle functionality
    themeToggleBtn.addEventListener('click', () => {
        if (body.classList.contains('dark-theme')) {
            body.classList.remove('dark-theme');
            body.classList.add('light-theme');
            localStorage.setItem('theme', 'light-theme');
        } else {
            body.classList.remove('light-theme');
            body.classList.add('dark-theme');
            localStorage.setItem('theme', 'dark-theme');
        }
    });

    // Profile Picture Change Functionality
    const profileImage = document.getElementById('profileImage');
    const profileImageInput = document.getElementById('profileImageInput');
    const changePhotoBtn = document.getElementById('changePhotoBtn');

    // Click the hidden file input when the change photo button is clicked
    changePhotoBtn.addEventListener('click', () => {
        profileImageInput.click();
    });

    // Handle file selection
    profileImageInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            // Check if the file is an image
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                
                reader.onload = (e) => {
                    // Update the profile image source
                    profileImage.src = e.target.result;
                    
                    // Save the image to localStorage
                    localStorage.setItem('profileImage', e.target.result);
                    
                    // Show success message
                    showNotification('Profile picture updated successfully!', 'success');
                };
                
                reader.readAsDataURL(file);
            } else {
                showNotification('Please select an image file.', 'error');
            }
        }
    });

    // Load saved profile image if exists
    const savedImage = localStorage.getItem('profileImage');
    if (savedImage) {
        profileImage.src = savedImage;
    }

    // Navigation Active State
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            navLinks.forEach(l => l.parentElement.classList.remove('active'));
            link.parentElement.classList.add('active');
        });
    });

    // Add Reminder
    const reminderForm = document.querySelector('.reminder-form');
    const remindersList = document.querySelector('.reminders-list');

    reminderForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const textInput = reminderForm.querySelector('input[type="text"]');
        const timeInput = reminderForm.querySelector('input[type="datetime-local"]');
        
        if (textInput.value && timeInput.value) {
            const reminderItem = document.createElement('div');
            reminderItem.className = 'reminder-item';
            
            const date = new Date(timeInput.value);
            const formattedDate = date.toLocaleString('en-US', {
                weekday: 'short',
                month: 'short',
                day: 'numeric',
                hour: 'numeric',
                minute: 'numeric'
            });

            reminderItem.innerHTML = `
                <i class="fas fa-bell"></i>
                <div class="reminder-content">
                    <p>${textInput.value}</p>
                    <small>${formattedDate}</small>
                </div>
                <button class="delete-btn"><i class="fas fa-trash"></i></button>
            `;

            // Add delete functionality
            const deleteBtn = reminderItem.querySelector('.delete-btn');
            deleteBtn.addEventListener('click', () => {
                reminderItem.remove();
                saveReminders();
            });

            remindersList.appendChild(reminderItem);
            saveReminders();

            // Clear form
            textInput.value = '';
            timeInput.value = '';
        }
    });

    // Save reminders to localStorage
    function saveReminders() {
        const reminders = [];
        document.querySelectorAll('.reminder-item').forEach(item => {
            reminders.push({
                text: item.querySelector('p').textContent,
                time: item.querySelector('small').textContent
            });
        });
        localStorage.setItem('reminders', JSON.stringify(reminders));
    }

    // Load saved reminders
    function loadReminders() {
        const savedReminders = JSON.parse(localStorage.getItem('reminders')) || [];
        savedReminders.forEach(reminder => {
            const reminderItem = document.createElement('div');
            reminderItem.className = 'reminder-item';
            reminderItem.innerHTML = `
                <i class="fas fa-bell"></i>
                <div class="reminder-content">
                    <p>${reminder.text}</p>
                    <small>${reminder.time}</small>
                </div>
                <button class="delete-btn"><i class="fas fa-trash"></i></button>
            `;

            const deleteBtn = reminderItem.querySelector('.delete-btn');
            deleteBtn.addEventListener('click', () => {
                reminderItem.remove();
                saveReminders();
            });

            remindersList.appendChild(reminderItem);
        });
    }

    // Load saved reminders on page load
    loadReminders();

    // Course Progress Animation
    const progressBars = document.querySelectorAll('.progress');
    progressBars.forEach(bar => {
        const width = bar.style.width;
        bar.style.width = '0';
        setTimeout(() => {
            bar.style.width = width;
        }, 100);
    });

    // Search Functionality
    const searchInput = document.querySelector('.search-bar input');
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const courseCards = document.querySelectorAll('.course-card');
        
        courseCards.forEach(card => {
            const title = card.querySelector('h3').textContent.toLowerCase();
            if (title.includes(searchTerm)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });

    // Grades Page Functionality
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize grade distribution chart animation
        const bars = document.querySelectorAll('.bar');
        bars.forEach(bar => {
            const width = bar.style.width;
            bar.style.width = '0';
            setTimeout(() => {
                bar.style.width = width;
            }, 100);
        });

        // Handle semester selection
        const semesterSelect = document.querySelector('.semester-select');
        if (semesterSelect) {
            semesterSelect.addEventListener('change', function() {
                // Here you would typically fetch new grade data based on the selected semester
                // For now, we'll just show a loading state
                const mainContent = document.querySelector('.main-content');
                mainContent.style.opacity = '0.5';
                
                // Simulate loading new data
                setTimeout(() => {
                    mainContent.style.opacity = '1';
                    // Update the grade statistics and table with new data
                    // This would be replaced with actual data fetching in a real application
                }, 500);
            });
        }

        // Handle grade table sorting
        const gradeTable = document.querySelector('.grades-table table');
        if (gradeTable) {
            const headers = gradeTable.querySelectorAll('th');
            headers.forEach((header, index) => {
                header.addEventListener('click', () => {
                    const rows = Array.from(gradeTable.querySelectorAll('tbody tr'));
                    const isAscending = header.classList.contains('asc');
                    
                    // Remove sort classes from all headers
                    headers.forEach(h => h.classList.remove('asc', 'desc'));
                    
                    // Sort rows
                    rows.sort((a, b) => {
                        const aValue = a.children[index].textContent;
                        const bValue = b.children[index].textContent;
                        
                        // Handle percentage values
                        if (aValue.includes('%')) {
                            const aNum = parseFloat(aValue);
                            const bNum = parseFloat(bValue);
                            return isAscending ? aNum - bNum : bNum - aNum;
                        }
                        
                        // Handle grade values
                        if (aValue.match(/^[A-Z][+-]?$/)) {
                            const gradeOrder = { 'A+': 0, 'A': 1, 'A-': 2, 'B+': 3, 'B': 4, 'B-': 5, 'C+': 6, 'C': 7, 'C-': 8 };
                            return isAscending ? 
                                gradeOrder[aValue] - gradeOrder[bValue] : 
                                gradeOrder[bValue] - gradeOrder[aValue];
                        }
                        
                        // Default string comparison
                        return isAscending ? 
                            aValue.localeCompare(bValue) : 
                            bValue.localeCompare(aValue);
                    });
                    
                    // Update table with sorted rows
                    const tbody = gradeTable.querySelector('tbody');
                    rows.forEach(row => tbody.appendChild(row));
                    
                    // Update header class
                    header.classList.add(isAscending ? 'desc' : 'asc');
                });
            });
        }
    });

    // Sidebar Toggle
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.sidebar');
    let sidebarOverlay;

    // Create sidebar overlay
    function createOverlay() {
        sidebarOverlay = document.createElement('div');
        sidebarOverlay.className = 'sidebar-overlay';
        document.body.appendChild(sidebarOverlay);

        // Close sidebar when clicking overlay
        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });
    }

    createOverlay();

    // Toggle sidebar
    sidebarToggle.addEventListener('click', () => {
        sidebar.classList.toggle('active');
        sidebarOverlay.classList.toggle('active');
    });

    // Close sidebar on window resize if screen becomes large
    window.addEventListener('resize', () => {
        if (window.innerWidth > 1024) {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        }
    });

    // Enhanced Kamboh Interactive Functionality
    function initializeKambohInteraction() {
        const kambohElements = document.querySelectorAll('.profile-section h2');
        
        kambohElements.forEach(element => {
            // Create tooltip
            const tooltip = document.createElement('div');
            tooltip.className = 'kamboh-tooltip';
            tooltip.innerHTML = `
                <div class="tooltip-content">
                    <h4>M Ashfaque</h4>
                    <p>Computer System Student</p>
                    <div class="tooltip-stats">
                        <span><i class="fas fa-user-graduate"></i> 22cs050</span>
                        <span><i class="fas fa-envelope"></i> kambohashfaque03@gmail.com</span>
                    </div>
                </div>
            `;
            element.parentElement.appendChild(tooltip);

            let isTooltipVisible = false;
            let tooltipTimeout;

            // Add click event
            element.addEventListener('click', () => {
                isTooltipVisible = !isTooltipVisible;
                tooltip.classList.toggle('show', isTooltipVisible);
                
                // Add animation effect
                element.classList.add('animate');
                setTimeout(() => {
                    element.classList.remove('animate');
                }, 1000);
            });

            // Add hover effect
            element.addEventListener('mouseenter', () => {
                clearTimeout(tooltipTimeout);
                element.style.transform = 'translateY(-2px) scale(1.02)';
            });

            element.addEventListener('mouseleave', () => {
                element.style.transform = '';
                if (!isTooltipVisible) {
                    tooltipTimeout = setTimeout(() => {
                        tooltip.classList.remove('show');
                    }, 300);
                }
            });

            // Position tooltip
            const updateTooltipPosition = () => {
                const rect = element.getBoundingClientRect();
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
                
                tooltip.style.top = `${rect.top + scrollTop - tooltip.offsetHeight - 10}px`;
                tooltip.style.left = `${rect.left + scrollLeft + (rect.width - tooltip.offsetWidth) / 2}px`;
            };

            // Update position on scroll and resize
            window.addEventListener('scroll', updateTooltipPosition);
            window.addEventListener('resize', updateTooltipPosition);

            // Initial position
            updateTooltipPosition();
        });
    }

    // Initialize when DOM is loaded
    initializeKambohInteraction();
});

// Notification function
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Add animation
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
} 